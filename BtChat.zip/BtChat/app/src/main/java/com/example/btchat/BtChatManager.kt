package com.example.btchat

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.util.UUID
import java.util.concurrent.atomic.AtomicLong

/**
 * قلب التطبيق: الاكتشاف، الاتصال عبر Bluetooth Classic (RFCOMM)، وإرسال/استقبال الرسائل.
 *
 * بروتوكول الرسالة على السوكيت:
 *   [1 بايت: النوع]
 *   نص:   [writeUTF(النص)]
 *   ملف:  [writeUTF(اسم الملف)] [writeLong(الحجم)] [البيانات خام]
 */
@SuppressLint("MissingPermission") // الصلاحيات تُطلب في الواجهة قبل استدعاء أي دالة هنا
class BtChatManager(context: Context) {

    companion object {
        val APP_UUID: UUID = UUID.fromString("8f3c1d52-6a7b-4e1c-9b2d-5a4c3e2f1a10")
        private const val CHUNK = 8 * 1024
        private val UNSAFE_NAME = Regex("[^\\w.\\-]")
    }

    private val app = context.applicationContext
    private val adapter: BluetoothAdapter? =
        (app.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // ---- حالة تنعرض في الواجهة ----
    private val _state = MutableStateFlow<ConnState>(ConnState.Idle)
    val state: StateFlow<ConnState> = _state

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages

    private val _devices = MutableStateFlow<List<DeviceItem>>(emptyList())
    val devices: StateFlow<List<DeviceItem>> = _devices

    private val _scanning = MutableStateFlow(false)
    val scanning: StateFlow<Boolean> = _scanning

    /** تقدم الإرسال/الاستقبال من 0 إلى 1، أو null إذا ماكو نقل شغال. */
    private val _progress = MutableStateFlow<Float?>(null)
    val progress: StateFlow<Float?> = _progress

    private val _errors = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val errors: SharedFlow<String> = _errors.asSharedFlow()

    val isAvailable: Boolean get() = adapter != null
    val isEnabled: Boolean get() = adapter?.isEnabled == true

    // ---- داخلي ----
    private var serverSocket: BluetoothServerSocket? = null
    private var socket: BluetoothSocket? = null
    private var output: DataOutputStream? = null
    private var sessionJob: Job? = null
    private var lastPeer: String? = null
    private val sendLock = Mutex()
    private val idGen = AtomicLong()

    private val receivedDir = File(app.filesDir, "received").apply { mkdirs() }
    private val sentDir = File(app.filesDir, "sent").apply { mkdirs() }

    fun newVoiceFile(): File = File(sentDir, "voice_${System.currentTimeMillis()}.m4a")

    // ------------------------------------------------------------------
    // الاكتشاف
    // ------------------------------------------------------------------

    private var receiverRegistered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, intent: Intent) {
            when (intent.action) {
                BluetoothDevice.ACTION_FOUND -> deviceFrom(intent)?.let { addDevice(it) }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> _scanning.value = false
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun deviceFrom(intent: Intent): BluetoothDevice? =
        if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
        } else {
            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
        }

    private fun addDevice(d: BluetoothDevice) {
        val item = DeviceItem(
            name = d.name ?: d.address,
            address = d.address,
            paired = d.bondState == BluetoothDevice.BOND_BONDED
        )
        _devices.update { list -> list.filter { it.address != item.address } + item }
    }

    fun loadPairedDevices() {
        runCatching {
            val paired = adapter?.bondedDevices.orEmpty().map {
                DeviceItem(it.name ?: it.address, it.address, true)
            }
            _devices.update { old ->
                val pairedAddresses = paired.map { it.address }.toSet()
                paired + old.filter { it.address !in pairedAddresses }
            }
        }
    }

    fun startDiscovery() {
        val a = adapter ?: return
        if (!receiverRegistered) {
            val filter = IntentFilter(BluetoothDevice.ACTION_FOUND).apply {
                addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            }
            ContextCompat.registerReceiver(app, receiver, filter, ContextCompat.RECEIVER_EXPORTED)
            receiverRegistered = true
        }
        loadPairedDevices()
        if (a.isDiscovering) a.cancelDiscovery()
        _scanning.value = a.startDiscovery()
    }

    // ------------------------------------------------------------------
    // الاتصال
    // ------------------------------------------------------------------

    /** هذا الجوال ينتظر اتصال من الجوال الثاني. */
    fun startListening() {
        val a = adapter ?: return
        disconnect()
        sessionJob = scope.launch {
            try {
                val server = a.listenUsingRfcommWithServiceRecord("BtChat", APP_UUID)
                serverSocket = server
                _state.value = ConnState.Listening
                val s = server.accept() // يبقى واقف لحد ما أحد يتصل
                runCatching { server.close() }
                serverSocket = null
                runSession(s)
            } catch (e: IOException) {
                if (currentCoroutineContext().isActive) {
                    _state.value = ConnState.Failed(e.message ?: "فشل الاستماع")
                }
            }
        }
    }

    /** هذا الجوال يتصل بجوال ينتظر. */
    fun connect(address: String) {
        val a = adapter ?: return
        disconnect()
        sessionJob = scope.launch {
            _state.value = ConnState.Connecting
            try {
                a.cancelDiscovery()
                _scanning.value = false
                val device = a.getRemoteDevice(address)
                val s = device.createRfcommSocketToServiceRecord(APP_UUID)
                s.connect()
                runSession(s)
            } catch (e: IOException) {
                if (currentCoroutineContext().isActive) {
                    _state.value = ConnState.Failed(
                        "ما قدرت أتصل. تأكد إن الجوال الثاني فاتح التطبيق وضاغط (انتظار اتصال)"
                    )
                }
            }
        }
    }

    fun disconnect() {
        sessionJob?.cancel()
        sessionJob = null
        runCatching { serverSocket?.close() }
        serverSocket = null
        runCatching { socket?.close() }
        socket = null
        output = null
        _progress.value = null
        _state.value = ConnState.Idle
    }

    private suspend fun runSession(s: BluetoothSocket) {
        socket = s
        val peerAddress = s.remoteDevice.address
        val peerName = s.remoteDevice.name ?: peerAddress
        if (peerAddress != lastPeer) {
            _messages.value = emptyList() // محادثة جديدة مع جهاز مختلف
            lastPeer = peerAddress
        }
        val input = DataInputStream(BufferedInputStream(s.inputStream))
        output = DataOutputStream(BufferedOutputStream(s.outputStream))
        _state.value = ConnState.Connected(peerName)
        try {
            while (currentCoroutineContext().isActive) {
                receiveOne(input)
            }
        } catch (e: IOException) {
            if (currentCoroutineContext().isActive) {
                _state.value = ConnState.Failed("انقطع الاتصال")
            }
        } finally {
            runCatching { s.close() }
            if (socket === s) {
                socket = null
                output = null
            }
            _progress.value = null
        }
    }

    // ------------------------------------------------------------------
    // الاستقبال
    // ------------------------------------------------------------------

    private fun receiveOne(input: DataInputStream) {
        val type = input.readUnsignedByte()
        if (type == MsgType.TEXT) {
            val text = input.readUTF()
            addMessage(ChatMessage(idGen.incrementAndGet(), MsgType.TEXT, text = text, fromMe = false))
            return
        }

        val name = input.readUTF()
        val size = input.readLong()
        if (size < 0) throw IOException("حجم ملف غير صحيح")

        val file = File(receivedDir, "${System.currentTimeMillis()}_${name.replace(UNSAFE_NAME, "_")}")
        try {
            FileOutputStream(file).use { out ->
                val buf = ByteArray(CHUNK)
                var left = size
                while (left > 0) {
                    val n = input.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                    if (n < 0) throw EOFException()
                    out.write(buf, 0, n)
                    left -= n
                    _progress.value = 1f - left.toFloat() / size
                }
            }
        } catch (e: IOException) {
            file.delete() // ملف ناقص ما ينفع
            throw e
        } finally {
            _progress.value = null
        }
        addMessage(
            ChatMessage(
                id = idGen.incrementAndGet(),
                type = type,
                path = file.absolutePath,
                fileName = name,
                fromMe = false
            )
        )
    }

    // ------------------------------------------------------------------
    // الإرسال
    // ------------------------------------------------------------------

    fun sendText(raw: String) {
        val text = raw.trim().take(15_000) // writeUTF حده 65535 بايت
        if (text.isEmpty()) return
        scope.launch {
            try {
                sendLock.withLock {
                    val o = output ?: throw IOException("غير متصل")
                    o.writeByte(MsgType.TEXT)
                    o.writeUTF(text)
                    o.flush()
                }
                addMessage(ChatMessage(idGen.incrementAndGet(), MsgType.TEXT, text = text, fromMe = true))
            } catch (e: IOException) {
                _errors.tryEmit("فشل إرسال الرسالة")
            }
        }
    }

    /** إرسال صورة/فيديو/ملف مختار من المعرض أو الملفات. */
    fun sendUri(uri: Uri) {
        scope.launch {
            try {
                val name = queryName(uri) ?: "file"
                val mime = app.contentResolver.getType(uri).orEmpty()
                val type = when {
                    mime.startsWith("image/") -> MsgType.IMAGE
                    mime.startsWith("video/") -> MsgType.VIDEO
                    mime.startsWith("audio/") -> MsgType.AUDIO
                    else -> MsgType.FILE
                }
                // ننسخ الملف محلياً أول لأن الحجم لازم يُرسل قبل البيانات
                val dest = File(sentDir, "${System.currentTimeMillis()}_${name.replace(UNSAFE_NAME, "_")}")
                val opened = app.contentResolver.openInputStream(uri)
                if (opened == null) {
                    _errors.tryEmit("ما قدرت أقرا الملف")
                    return@launch
                }
                opened.use { i -> FileOutputStream(dest).use { o -> i.copyTo(o) } }
                transmitFile(dest, name, type)
            } catch (e: IOException) {
                _progress.value = null
                _errors.tryEmit("فشل إرسال الملف")
            }
        }
    }

    /** إرسال ملف موجود محلياً (مثل الفويس اللي تسجل توّه). */
    fun sendLocalFile(file: File, type: Int) {
        scope.launch {
            try {
                transmitFile(file, file.name, type)
            } catch (e: IOException) {
                _progress.value = null
                _errors.tryEmit("فشل إرسال الملف")
            }
        }
    }

    private suspend fun transmitFile(file: File, name: String, type: Int) {
        val total = file.length()
        sendLock.withLock {
            val o = output ?: throw IOException("غير متصل")
            o.writeByte(type)
            o.writeUTF(name)
            o.writeLong(total)
            FileInputStream(file).use { i ->
                val buf = ByteArray(CHUNK)
                var sent = 0L
                while (true) {
                    val n = i.read(buf)
                    if (n < 0) break
                    o.write(buf, 0, n)
                    sent += n
                    if (total > 0) _progress.value = sent.toFloat() / total
                }
            }
            o.flush()
            _progress.value = null
        }
        addMessage(
            ChatMessage(
                id = idGen.incrementAndGet(),
                type = type,
                path = file.absolutePath,
                fileName = name,
                fromMe = true
            )
        )
    }

    // ------------------------------------------------------------------

    private fun addMessage(m: ChatMessage) {
        _messages.update { it + m }
    }

    private fun queryName(uri: Uri): String? =
        app.contentResolver
            .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
}
