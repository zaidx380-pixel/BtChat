package com.example.btchat

import android.app.Application

class BtChatApp : Application() {
    /** مدير البلوتوث واحد لكل التطبيق حتى ما ينقطع الاتصال لو تغيّرت الشاشة. */
    val chat: BtChatManager by lazy { BtChatManager(this) }
}
