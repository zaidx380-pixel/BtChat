package com.example.btchat

/** أنواع الرسائل في بروتوكول النقل (أول بايت قبل كل رسالة). */
object MsgType {
    const val TEXT = 0
    const val IMAGE = 1
    const val VIDEO = 2
    const val AUDIO = 3
    const val FILE = 4
}

data class ChatMessage(
    val id: Long,
    val type: Int,
    val text: String = "",
    val path: String? = null,
    val fileName: String = "",
    val fromMe: Boolean,
    val time: Long = System.currentTimeMillis()
)

data class DeviceItem(
    val name: String,
    val address: String,
    val paired: Boolean
)

sealed interface ConnState {
    object Idle : ConnState
    object Listening : ConnState
    object Connecting : ConnState
    data class Connected(val name: String) : ConnState
    data class Failed(val reason: String) : ConnState
}
