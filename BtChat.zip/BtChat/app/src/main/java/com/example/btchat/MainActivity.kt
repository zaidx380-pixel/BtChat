package com.example.btchat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val chat = (application as BtChatApp).chat

        setContent {
            MaterialTheme {
                // الواجهة عربية، فنخلي الاتجاه من اليمين لليسار دائماً
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(modifier = Modifier.fillMaxSize()) {
                        val state by chat.state.collectAsStateWithLifecycle()
                        val current = state
                        if (current is ConnState.Connected) {
                            ChatScreen(chat = chat, peer = current.name)
                        } else {
                            ConnectScreen(chat = chat, state = current)
                        }
                    }
                }
            }
        }
    }
}
