package com.example.btchat

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.MediaPlayer
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.exifinterface.media.ExifInterface
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ChatScreen(chat: BtChatManager, peer: String) {
    val context = LocalContext.current
    val messages by chat.messages.collectAsStateWithLifecycle()
    val progress by chat.progress.collectAsStateWithLifecycle()

    var input by remember { mutableStateOf("") }
    var recording by remember { mutableStateOf(false) }
    val recorder = remember { VoiceRecorder(context) }
    val listState = rememberLazyListState()

    // أخطاء الإرسال تطلع كرسالة صغيرة
    LaunchedEffect(Unit) {
        chat.errors.collect { Toast.makeText(context, it, Toast.LENGTH_SHORT).show() }
    }

    // نزّل لآخر رسالة
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }

    DisposableEffect(Unit) {
        onDispose { recorder.stop() }
    }

    val mediaPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri -> if (uri != null) chat.sendUri(uri) }

    val filePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri -> if (uri != null) chat.sendUri(uri) }

    fun startRecording() {
        val file = chat.newVoiceFile()
        if (recorder.start(file)) {
            recording = true
        } else {
            Toast.makeText(context, "ما قدرت أبدي التسجيل", Toast.LENGTH_SHORT).show()
        }
    }

    fun stopRecordingAndSend() {
        recording = false
        val file = recorder.stop()
        if (file != null) {
            chat.sendLocalFile(file, MsgType.AUDIO)
        } else {
            Toast.makeText(context, "التسجيل قصير جداً", Toast.LENGTH_SHORT).show()
        }
    }

    val micPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startRecording()
        else Toast.makeText(context, "لازم تسمح بالمايك حتى تسجل فويس", Toast.LENGTH_SHORT).show()
    }

    fun onMicClick() {
        if (recording) {
            stopRecordingAndSend()
        } else if (
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            startRecording()
        } else {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // الشريط العلوي
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("محادثة مع $peer", style = MaterialTheme.typography.titleMedium)
            TextButton(onClick = { chat.disconnect() }) { Text("قطع الاتصال") }
        }

        progress?.let { p ->
            LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth())
        }

        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(messages, key = { it.id }) { MessageBubble(it) }
        }

        // شريط الإدخال
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(
                onClick = {
                    mediaPicker.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                    )
                },
                contentPadding = PaddingValues(4.dp)
            ) { Text("🖼", fontSize = 22.sp) }

            TextButton(
                onClick = { filePicker.launch("*/*") },
                contentPadding = PaddingValues(4.dp)
            ) { Text("📎", fontSize = 22.sp) }

            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text(if (recording) "جاري التسجيل..." else "اكتب رسالة") },
                enabled = !recording,
                maxLines = 4
            )

            if (input.isBlank()) {
                TextButton(onClick = { onMicClick() }, contentPadding = PaddingValues(4.dp)) {
                    Text(if (recording) "⏹" else "🎤", fontSize = 24.sp)
                }
            } else {
                TextButton(
                    onClick = {
                        chat.sendText(input)
                        input = ""
                    },
                    contentPadding = PaddingValues(4.dp)
                ) { Text("➤", fontSize = 24.sp) }
            }
        }
    }
}

@Composable
fun MessageBubble(m: ChatMessage) {
    val context = LocalContext.current
    val timeText = remember(m.time) {
        SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(m.time))
    }

    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = if (m.fromMe) Alignment.CenterStart else Alignment.CenterEnd
    ) {
        Surface(
            color = if (m.fromMe) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.widthIn(max = 290.dp)
        ) {
            Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                val path = m.path
                when (m.type) {
                    MsgType.TEXT -> Text(m.text)

                    MsgType.IMAGE -> if (path != null) {
                        val bitmap by produceState<Bitmap?>(initialValue = null, path) {
                            value = withContext(Dispatchers.IO) { decodeSampled(path, 700) }
                        }
                        val bmp = bitmap
                        if (bmp != null) {
                            Image(
                                bitmap = bmp.asImageBitmap(),
                                contentDescription = m.fileName,
                                contentScale = ContentScale.Fit,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { openFile(context, path, "image/*") }
                            )
                        } else {
                            Text("🖼 ${m.fileName}")
                        }
                    }

                    MsgType.VIDEO -> if (path != null) {
                        Text("🎬 ${m.fileName}")
                        Button(onClick = { openFile(context, path, "video/*") }) { Text("تشغيل الفيديو") }
                    }

                    MsgType.AUDIO -> if (path != null) AudioContent(path)

                    else -> if (path != null) {
                        Text("📄 ${m.fileName}")
                        Button(onClick = { openFile(context, path, guessMime(m.fileName)) }) { Text("فتح الملف") }
                    }
                }
                Text(timeText, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun AudioContent(path: String) {
    var playing by remember { mutableStateOf(false) }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }

    DisposableEffect(path) {
        onDispose { player?.release() }
    }

    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("🎤")
        Button(onClick = {
            if (playing) {
                player?.release()
                player = null
                playing = false
            } else {
                val p = MediaPlayer()
                try {
                    p.setDataSource(path)
                    p.prepare()
                    p.setOnCompletionListener {
                        it.release()
                        player = null
                        playing = false
                    }
                    p.start()
                    player = p
                    playing = true
                } catch (e: Exception) {
                    p.release()
                }
            }
        }) { Text(if (playing) "⏹ إيقاف" else "▶ تشغيل الفويس") }
    }
}

/** يقرا الصورة بحجم مصغّر حتى ما تخلص الذاكرة، ويصلّح دورانها حسب EXIF. */
private fun decodeSampled(path: String, maxDim: Int): Bitmap? = runCatching {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, bounds)
    var sample = 1
    while (bounds.outWidth / (sample * 2) >= maxDim && bounds.outHeight / (sample * 2) >= maxDim) {
        sample *= 2
    }
    val bmp = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
        ?: return@runCatching null
    val degrees = when (
        ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
    ) {
        ExifInterface.ORIENTATION_ROTATE_90 -> 90f
        ExifInterface.ORIENTATION_ROTATE_180 -> 180f
        ExifInterface.ORIENTATION_ROTATE_270 -> 270f
        else -> 0f
    }
    if (degrees == 0f) bmp
    else Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(degrees) }, true)
}.getOrNull()

private fun guessMime(fileName: String): String {
    val ext = fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)
    return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
}

private fun openFile(context: Context, path: String, mime: String) {
    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", File(path))
    val intent = Intent(Intent.ACTION_VIEW)
        .setDataAndType(uri, mime)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    try {
        context.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, "ما لكيت تطبيق يفتح هذا الملف", Toast.LENGTH_SHORT).show()
    }
}
