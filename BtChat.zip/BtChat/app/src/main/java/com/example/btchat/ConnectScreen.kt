package com.example.btchat

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle

private fun btPermissions(): List<String> =
    if (Build.VERSION.SDK_INT >= 31) {
        listOf(
            Manifest.permission.BLUETOOTH_CONNECT,
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_ADVERTISE
        )
    } else {
        listOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }

@Composable
fun ConnectScreen(chat: BtChatManager, state: ConnState) {
    val context = LocalContext.current
    val devices by chat.devices.collectAsStateWithLifecycle()
    val scanning by chat.scanning.collectAsStateWithLifecycle()

    // الإجراء اللي ينتظر الصلاحيات / تشغيل البلوتوث
    var pending by remember { mutableStateOf<(() -> Unit)?>(null) }

    val enableLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        val action = pending
        pending = null
        if (chat.isEnabled) action?.invoke()
    }

    fun proceed() {
        val action = pending ?: return
        if (!chat.isEnabled) {
            enableLauncher.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
        } else {
            pending = null
            action()
        }
    }

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result.values.all { it }) {
            proceed()
        } else {
            pending = null
            Toast.makeText(context, "لازم توافق على صلاحيات البلوتوث حتى يشتغل التطبيق", Toast.LENGTH_LONG).show()
        }
    }

    fun withBluetooth(action: () -> Unit) {
        if (!chat.isAvailable) {
            Toast.makeText(context, "هذا الجهاز ما يدعم البلوتوث", Toast.LENGTH_LONG).show()
            return
        }
        pending = action
        val missing = btPermissions().filter {
            ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) proceed() else permLauncher.launch(missing.toTypedArray())
    }

    LaunchedEffect(Unit) { chat.loadPairedDevices() }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("مراسلة بلوتوث", style = MaterialTheme.typography.headlineSmall)

        val statusText = when (state) {
            ConnState.Idle -> "غير متصل"
            ConnState.Listening -> "بانتظار الجوال الثاني يتصل..."
            ConnState.Connecting -> "جاري الاتصال..."
            is ConnState.Failed -> state.reason
            is ConnState.Connected -> "متصل"
        }
        Text(statusText, style = MaterialTheme.typography.bodyLarge)

        Text(
            "الجوال الأول: اضغط (انتظار اتصال).\nالجوال الثاني: اختر اسم الجوال الأول من القائمة.",
            style = MaterialTheme.typography.bodySmall
        )

        if (state == ConnState.Listening || state == ConnState.Connecting) {
            OutlinedButton(onClick = { chat.disconnect() }, modifier = Modifier.fillMaxWidth()) {
                Text("إلغاء")
            }
        } else {
            Button(
                onClick = {
                    withBluetooth {
                        // نخلي الجوال ظاهر للبحث 5 دقايق ونبدأ الاستماع
                        val discoverable = Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                            .putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300)
                        context.startActivity(discoverable)
                        chat.startListening()
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("انتظار اتصال") }

            OutlinedButton(
                onClick = { withBluetooth { chat.startDiscovery() } },
                modifier = Modifier.fillMaxWidth()
            ) { Text("بحث عن أجهزة") }
        }

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("الأجهزة", style = MaterialTheme.typography.titleMedium)
            if (scanning) CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(devices, key = { it.address }) { d ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { withBluetooth { chat.connect(d.address) } }
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text(d.name, style = MaterialTheme.typography.titleSmall)
                        Text(
                            d.address + if (d.paired) "  •  مقترن" else "",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }
}
